/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//Mac/Home/Desktop/New_Processor_R_FPGA_demo_included/Codes/FPGA_Demo_Plan/BTN_anti_coli.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_3620187407_sub_4042748798_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_1706799881_3212880686_p_0(char *t0)
{
    char t7[16];
    char t13[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned char t12;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    int t25;
    int t26;
    int t27;
    int t28;
    int t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3312);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(67, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 5864U);
    t5 = (t0 + 5960);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 0;
    t9 = (t8 + 4U);
    *((int *)t9) = 4;
    t9 = (t8 + 8U);
    *((int *)t9) = 1;
    t10 = (4 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t12 = ieee_p_3620187407_sub_4042748798_3965413181(IEEE_P_3620187407, t4, t3, t5, t7);
    if (t12 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(68, ng0);
    t9 = (t0 + 1832U);
    t14 = *((char **)t9);
    t9 = (t0 + 5896U);
    t15 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t13, t14, t9, 1);
    t16 = (t13 + 12U);
    t11 = *((unsigned int *)t16);
    t17 = (1U * t11);
    t18 = (32U != t17);
    if (t18 == 1)
        goto LAB8;

LAB9:    t19 = (t0 + 3392);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t15, 32U);
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1832U);
    t3 = *((char **)t1);
    t10 = (25 - 31);
    t11 = (t10 * -1);
    t17 = (1U * t11);
    t24 = (0 + t17);
    t1 = (t3 + t24);
    t2 = *((unsigned char *)t1);
    t12 = (t2 == (unsigned char)3);
    if (t12 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(84, ng0);
    t1 = xsi_get_transient_memory(5U);
    memset(t1, 0, 5U);
    t3 = t1;
    memset(t3, (unsigned char)2, 5U);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);

LAB11:    goto LAB6;

LAB8:    xsi_size_not_matching(32U, t17, 0);
    goto LAB9;

LAB10:    xsi_set_current_line(72, ng0);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t4 = (t0 + 5965);
    t25 = xsi_mem_cmp(t4, t5, 5U);
    if (t25 == 1)
        goto LAB14;

LAB20:    t8 = (t0 + 5970);
    t26 = xsi_mem_cmp(t8, t5, 5U);
    if (t26 == 1)
        goto LAB15;

LAB21:    t14 = (t0 + 5975);
    t27 = xsi_mem_cmp(t14, t5, 5U);
    if (t27 == 1)
        goto LAB16;

LAB22:    t16 = (t0 + 5980);
    t28 = xsi_mem_cmp(t16, t5, 5U);
    if (t28 == 1)
        goto LAB17;

LAB23:    t20 = (t0 + 5985);
    t29 = xsi_mem_cmp(t20, t5, 5U);
    if (t29 == 1)
        goto LAB18;

LAB24:
LAB19:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 6015);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);

LAB13:    xsi_set_current_line(82, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t3 = t1;
    memset(t3, (unsigned char)2, 32U);
    t4 = (t0 + 3392);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB11;

LAB14:    xsi_set_current_line(73, ng0);
    t22 = (t0 + 5990);
    t30 = (t0 + 3456);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memcpy(t34, t22, 5U);
    xsi_driver_first_trans_fast_port(t30);
    goto LAB13;

LAB15:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 5995);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB13;

LAB16:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 6000);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB13;

LAB17:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 6005);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB13;

LAB18:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 6010);
    t4 = (t0 + 3456);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB13;

LAB25:;
}


extern void work_a_1706799881_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1706799881_3212880686_p_0};
	xsi_register_didat("work_a_1706799881_3212880686", "isim/tb_FPGA_TOP_isim_beh.exe.sim/work/a_1706799881_3212880686.didat");
	xsi_register_executes(pe);
}
