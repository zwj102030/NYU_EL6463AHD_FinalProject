/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//Mac/Home/Desktop/New_Processor_R_FPGA_demo_included/Codes/control_unit.vhd";
extern char *IEEE_P_3620187407;



static void work_a_3853510154_3212880686_p_0(char *t0)
{
    char t5[16];
    char t20[16];
    char t46[16];
    char t49[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    int t21;
    unsigned char t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    int t28;
    int t29;
    int t30;
    int t31;
    int t32;
    char *t33;
    int t34;
    char *t35;
    char *t36;
    int t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned char t45;
    unsigned char t47;
    unsigned char t48;
    unsigned char t50;

LAB0:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7072);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7078);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t19 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t19 == 1)
        goto LAB7;

LAB8:    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t7 = (t0 + 7004U);
    t14 = (t0 + 7084);
    t16 = (t20 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 5;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t21 = (5 - 0);
    t9 = (t21 * 1);
    t9 = (t9 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t9;
    t22 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t14, t20);
    t10 = t22;

LAB9:    if (t10 != 0)
        goto LAB5;

LAB6:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t9 = (5 - 3);
    t12 = (t9 * 1U);
    t13 = (0 + t12);
    t1 = (t2 + t13);
    t3 = (t0 + 7094);
    t8 = xsi_mem_cmp(t3, t1, 4U);
    if (t8 == 1)
        goto LAB11;

LAB21:    t6 = (t0 + 7098);
    t21 = xsi_mem_cmp(t6, t1, 4U);
    if (t21 == 1)
        goto LAB12;

LAB22:    t11 = (t0 + 7102);
    t28 = xsi_mem_cmp(t11, t1, 4U);
    if (t28 == 1)
        goto LAB13;

LAB23:    t15 = (t0 + 7106);
    t29 = xsi_mem_cmp(t15, t1, 4U);
    if (t29 == 1)
        goto LAB14;

LAB24:    t17 = (t0 + 7110);
    t30 = xsi_mem_cmp(t17, t1, 4U);
    if (t30 == 1)
        goto LAB15;

LAB25:    t23 = (t0 + 7114);
    t31 = xsi_mem_cmp(t23, t1, 4U);
    if (t31 == 1)
        goto LAB16;

LAB26:    t25 = (t0 + 7118);
    t32 = xsi_mem_cmp(t25, t1, 4U);
    if (t32 == 1)
        goto LAB17;

LAB27:    t27 = (t0 + 7122);
    t34 = xsi_mem_cmp(t27, t1, 4U);
    if (t34 == 1)
        goto LAB18;

LAB28:    t35 = (t0 + 7126);
    t37 = xsi_mem_cmp(t35, t1, 4U);
    if (t37 == 1)
        goto LAB19;

LAB29:
LAB20:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 7166);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB10:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7170);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB31;

LAB33:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 4096);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB32:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7176);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB34;

LAB36:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 4160);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB35:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7182);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t22 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t22 == 1)
        goto LAB43;

LAB44:    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t7 = (t0 + 7004U);
    t14 = (t0 + 7188);
    t16 = (t20 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 5;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t21 = (5 - 0);
    t9 = (t21 * 1);
    t9 = (t9 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t9;
    t45 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t14, t20);
    t19 = t45;

LAB45:    if (t19 == 1)
        goto LAB40;

LAB41:    t17 = (t0 + 1032U);
    t18 = *((char **)t17);
    t17 = (t0 + 7004U);
    t23 = (t0 + 7194);
    t25 = (t46 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = 0;
    t26 = (t25 + 4U);
    *((int *)t26) = 5;
    t26 = (t25 + 8U);
    *((int *)t26) = 1;
    t28 = (5 - 0);
    t9 = (t28 * 1);
    t9 = (t9 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t9;
    t47 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t18, t17, t23, t46);
    t10 = t47;

LAB42:    if (t10 != 0)
        goto LAB37;

LAB39:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4224);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4288);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB38:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 4352);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(103, ng0);
    t1 = (t0 + 4480);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(105, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7004U);
    t3 = (t0 + 7200);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t45 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t45 == 1)
        goto LAB55;

LAB56:    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t7 = (t0 + 7004U);
    t14 = (t0 + 7206);
    t16 = (t20 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 5;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t21 = (5 - 0);
    t9 = (t21 * 1);
    t9 = (t9 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t9;
    t47 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t14, t20);
    t22 = t47;

LAB57:    if (t22 == 1)
        goto LAB52;

LAB53:    t17 = (t0 + 1032U);
    t18 = *((char **)t17);
    t17 = (t0 + 7004U);
    t23 = (t0 + 7212);
    t25 = (t46 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = 0;
    t26 = (t25 + 4U);
    *((int *)t26) = 5;
    t26 = (t25 + 8U);
    *((int *)t26) = 1;
    t28 = (5 - 0);
    t9 = (t28 * 1);
    t9 = (t9 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t9;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t18, t17, t23, t46);
    t19 = t48;

LAB54:    if (t19 == 1)
        goto LAB49;

LAB50:    t26 = (t0 + 1032U);
    t27 = *((char **)t26);
    t26 = (t0 + 7004U);
    t33 = (t0 + 7218);
    t36 = (t49 + 0U);
    t38 = (t36 + 0U);
    *((int *)t38) = 0;
    t38 = (t36 + 4U);
    *((int *)t38) = 5;
    t38 = (t36 + 8U);
    *((int *)t38) = 1;
    t29 = (5 - 0);
    t9 = (t29 * 1);
    t9 = (t9 + 1);
    t38 = (t36 + 12U);
    *((unsigned int *)t38) = t9;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t27, t26, t33, t49);
    t10 = t50;

LAB51:    if (t10 != 0)
        goto LAB46;

LAB48:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 4416);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB47:
LAB3:    t1 = (t0 + 3952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(61, ng0);
    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = (5 - 3);
    t12 = (t9 * 1U);
    t13 = (0 + t12);
    t7 = (t11 + t13);
    t14 = (t0 + 4032);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t7, 4U);
    xsi_driver_first_trans_fast_port(t14);
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 4096);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 4160);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 4224);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 4288);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(66, ng0);
    t1 = (t0 + 4352);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(67, ng0);
    t1 = (t0 + 4416);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4480);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(71, ng0);
    t17 = (t0 + 7090);
    t23 = (t0 + 4032);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t17, 4U);
    xsi_driver_first_trans_fast_port(t23);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 4096);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(73, ng0);
    t1 = (t0 + 4160);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(74, ng0);
    t1 = (t0 + 4224);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(75, ng0);
    t1 = (t0 + 4288);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4352);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4416);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 4480);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB7:    t10 = (unsigned char)1;
    goto LAB9;

LAB11:    xsi_set_current_line(81, ng0);
    t38 = (t0 + 7130);
    t40 = (t0 + 4032);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    memcpy(t44, t38, 4U);
    xsi_driver_first_trans_fast_port(t40);
    goto LAB10;

LAB12:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 7134);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB13:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 7138);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB14:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 7142);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB15:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 7146);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB16:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 7150);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB17:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 7154);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB18:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 7158);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB19:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 7162);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB10;

LAB30:;
LAB31:    xsi_set_current_line(96, ng0);
    t7 = (t0 + 4096);
    t11 = (t7 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB32;

LAB34:    xsi_set_current_line(97, ng0);
    t7 = (t0 + 4160);
    t11 = (t7 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB35;

LAB37:    xsi_set_current_line(99, ng0);
    t26 = (t0 + 4224);
    t27 = (t26 + 56U);
    t33 = *((char **)t27);
    t35 = (t33 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t26);
    xsi_set_current_line(99, ng0);
    t1 = (t0 + 4288);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB38;

LAB40:    t10 = (unsigned char)1;
    goto LAB42;

LAB43:    t19 = (unsigned char)1;
    goto LAB45;

LAB46:    xsi_set_current_line(106, ng0);
    t38 = (t0 + 4416);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    *((unsigned char *)t42) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t38);
    goto LAB47;

LAB49:    t10 = (unsigned char)1;
    goto LAB51;

LAB52:    t19 = (unsigned char)1;
    goto LAB54;

LAB55:    t22 = (unsigned char)1;
    goto LAB57;

}


extern void work_a_3853510154_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3853510154_3212880686_p_0};
	xsi_register_didat("work_a_3853510154_3212880686", "isim/tb_mips_isim_beh.exe.sim/work/a_3853510154_3212880686.didat");
	xsi_register_executes(pe);
}
