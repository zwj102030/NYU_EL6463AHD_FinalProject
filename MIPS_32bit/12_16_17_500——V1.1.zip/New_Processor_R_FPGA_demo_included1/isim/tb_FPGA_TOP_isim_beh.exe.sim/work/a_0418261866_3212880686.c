/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//Mac/Home/Desktop/FinalProject_12_15_17_729/New_Processor_R_FPGA_demo_included/Codes/signext_16_to_32.vhd";
extern char *IEEE_P_3499444699;

char *ieee_p_3499444699_sub_871414444_3536714472(char *, char *, char *, char *, int );


static void work_a_0418261866_3212880686_p_0(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(43, ng0);

LAB3:    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 4596U);
    t4 = ieee_p_3499444699_sub_871414444_3536714472(IEEE_P_3499444699, t1, t3, t2, 32);
    t5 = (t1 + 12U);
    t6 = *((unsigned int *)t5);
    t6 = (t6 * 1U);
    t7 = (32U != t6);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 2752);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t4, 32U);
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 2672);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t6, 0);
    goto LAB6;

}


extern void work_a_0418261866_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0418261866_3212880686_p_0};
	xsi_register_didat("work_a_0418261866_3212880686", "isim/tb_FPGA_TOP_isim_beh.exe.sim/work/a_0418261866_3212880686.didat");
	xsi_register_executes(pe);
}
